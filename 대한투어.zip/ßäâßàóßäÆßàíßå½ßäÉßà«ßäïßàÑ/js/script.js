$(document).ready(function(){
    $("#gnb>li").mouseover (function(){
        $(".lnb,#bg").stop().slideDown();
        $("#gnb>li").mouseout (function(){
        $(".lnb,#bg").stop().slideUp();
    })
})
})

// var count=3;
// var current=0;
// var position;
// setInterval (funciton(){
//     if (current < count-1){
//         current++;}
//     else {current=0;}
//     position=current*(-300)+"px";
//     $("#total").animate({top:position},500);
// },3000);


// var count=3;
// var current=0;
// var position;
// setInterval(function(){
//     if(current<count-1){
//         current++;}
//     else{current=0;}
//     position=current*(-300)+"px";
//     $("#total").animate({top:position},500);
// },3000);

var count =3;
var current=0;
var position;
setInterval (function(){
    if (current<count-1) {current ++;}
    else {current=0;}
    position=current*(-300)+"px"
    $("#total").animate({top:position},500);
},4000);

$(document).ready(function(){
    $("#modalopen").click(function(){
        $("#modal").show();
        $("button").click(function(){
            $("#modal").hide();
        })
    })
})